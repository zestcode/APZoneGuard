
import type { Zone, AP } from './dashboard/src/types';
import { ZoneType } from './dashboard/src/types';

export const WAREHOUSE_WIDTH = 1000;
export const WAREHOUSE_HEIGHT = 600;

export const ACCESS_POINTS: AP[] = [
  { id: 'ap-1', label: 'AP_NORTH_WEST', position: { x: 50, y: 50 }, status: 'online' },
  { id: 'ap-2', label: 'AP_NORTH_EAST', position: { x: 950, y: 50 }, status: 'online' },
  { id: 'ap-3', label: 'AP_SOUTH_WEST', position: { x: 50, y: 550 }, status: 'online' },
  { id: 'ap-4', label: 'AP_SOUTH_EAST', position: { x: 950, y: 550 }, status: 'online' },
];

export const ZONES: Zone[] = [
  {
    id: 'zone-a',
    name: 'Zone A (Rest Lounge)',
    type: ZoneType.REST,
    color: 'rgba(34, 197, 94, 0.15)',
    points: [{ x: 50, y: 50 }, { x: 400, y: 50 }, { x: 400, y: 250 }, { x: 50, y: 250 }]
  },
  {
    id: 'zone-b',
    name: 'Zone B (Sorting - Work)',
    type: ZoneType.WORK,
    color: 'rgba(249, 115, 22, 0.15)',
    points: [{ x: 450, y: 50 }, { x: 950, y: 50 }, { x: 950, y: 250 }, { x: 450, y: 250 }]
  },
  {
    id: 'zone-c',
    name: 'Zone C (Loading - Work)',
    type: ZoneType.WORK,
    color: 'rgba(249, 115, 22, 0.15)',
    points: [{ x: 50, y: 300 }, { x: 950, y: 300 }, { x: 950, y: 550 }, { x: 50, y: 550 }]
  }
];
